"""
Wrapper to make api calls
"""

import requests
try:
    from urllib.parse import urljoin
except ImportError:
    from urlparse import urljoin

from amorphicutils.amorphiclogging import Log4j
from .endpoints import OPERATION_API_PATH

LOGGER = Log4j().get_logger()


class ApiWrapper:
    """
    Class to wrap requests calls
    """

    def __init__(self, url, env, auth_key, role_id):
        self._headers = {
            "Authorization": auth_key,
            "role_id": role_id
        }
        self._url = url
        self.env = env

    def build_url(self, operation, fields=None):
        """
        Build the url on which the request call will be made.

        :param operation: keyword or operation from endpoints.py
        :param fields: Any dynamic path in url
        :return:
        """

        LOGGER.debug("Building full url for amorphic api with url={url}, environment={env} "
                     "operation={opr}, fields={fields}."
                     .format(url=self._url, env=self.env, opr=operation, fields=fields))
        try:
            _path = OPERATION_API_PATH[operation]
            LOGGER.debug("Path for api call is: {path}".format(path=_path))
        except KeyError as key_err:
            LOGGER.error("Operation {opr} not defined under endpoints with error: {err}".format(
                opr=operation, err=key_err))
            raise Exception("Operation {opr} not defined under endpoints.".format(opr=operation))

        try:
            if fields:
                full_url = urljoin(self._url, "/".join([self.env, _path.format(fields)]))
            else:
                full_url = urljoin(self._url, "/".join([self.env, _path]))
        except KeyError as key_err:
            LOGGER.error("Failed to create full url with error: {err}".format(err=key_err))
            raise Exception("Failed to create full url.")

        LOGGER.debug("Built url is: {url}".format(url=full_url))

        return full_url

    def make_request(self, operation=None, fields=None, method='get',
                     headers=None, data=None, verify=True, timeout=30, custom_url=None, **params):
        """
        Make the request call to Amorphic API

        :param operation: keyword or operation from endpoints.py
        :param fields: Any dynamic path in url
        :param method: One of the following POST, GET, PUT, DELETE
        :param headers: Extra headers to the requests
        :param data: Payload for the request call
        :param verify: If need to verify for SSL connection. Default: True
        :param timeout: Timeout for the API call. Default: 30
        :param custom_url: url to any other custom query
        :param params: Any extra params for request call
        :return:
        """

        if custom_url:
            full_url = custom_url
        elif operation:
            # Build url
            full_url = self.build_url(operation, fields)
        else:
            raise Exception("Either operation or custom_url must be supplied.")

        # Building headers
        if headers:
            self._headers.update(headers)

        LOGGER.debug("Making {method} call on {url}".format(method=method, url=full_url))
        LOGGER.debug("Payload for the request is {payload}".format(payload=data))

        request = getattr(requests, method.lower())
        response = request(full_url, headers=self._headers, data=data, verify=verify, timeout=timeout, params=params)
        return response
