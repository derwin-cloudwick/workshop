"""
List of api path for amorphicdata
"""

OPERATION_API_PATH = {
    "health_check": "/healthcheck",
    "register_dataset": "/datasets",
    "dataset_details": "/datasets/{0}",
    "update_dataset": "/datasets/{0}/updatemetadata",
    "search_dataset": "/datasets/search/?queryString={0}",
    "domains": "/domains",
    "domain_details": "/domains/{0}",
    "jobs": "/jobs",
    "job_path": "/jobs/{0}",
    "job_script_path": "/jobs/{0}/script",
    "job_extra_res_path": "/jobs/{0}/resourceaccess",
    "start_job": "/jobs/{id}/executions",
    "stop_job": "/jobs/{id}/executions/{executionid}",
    "job_libs": "/jobs/{0}/libs",
    "common_libs": "/jobs/libs",
    "common_libs_details": "/jobs/libs/{0}",
    "resourcetype_datasets": "/resourcetypes/datasets/resources/{0}",
    "resourcetype_jobs": "/resourcetypes/jobs/resources/{0}",
    "views": "/views",
    "view_details": "/views/{0}"
}
