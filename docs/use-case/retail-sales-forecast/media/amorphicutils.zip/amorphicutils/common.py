"""
Contain functions which are common accross multiple modules.
"""

import functools
import time
import boto3
from botocore.exceptions import ClientError

from amorphicutils import awshelper
from amorphicutils.amorphiclogging import Log4j
from amorphicutils.errors import ReturnTypeNotBooleanException, ResultFalseException, ResultTrueException


LOGGER = Log4j().get_logger()


def format_response(exitcode, message, data=None):
    """
    Create a standard response for the function calls

    :param exitcode: 0 for success and 1 for failure
    :param message: Message for the outcome
    :param data: Data of the response
    :return:
    """
    return {
        "exitcode": exitcode,
        "message": message,
        "data": data
    }


def retry(retry_count=5, delay=2, allowed_exceptions=()):
    """
    Function to be used as decorator for retry mechanism

    :param retry_count: number of retry the function is executed
    :param delay: the seconds it wait after each execution
    :param allowed_exceptions: the exceptions which are allowed for retry
    :return:

    >>> @retry(3, 2)
        def func(a, b):
            return a/b
    >>> func(5,3)
    """
    def decorator(function):
        @functools.wraps(function)
        def wrapper(*args, **kwargs):
            last_exception = None
            for _ in range(retry_count):
                try:
                    LOGGER.info("Trying for %s time.", _)
                    result = function(*args, **kwargs)
                    if result:
                        return result
                except allowed_exceptions as ex:
                    last_exception = ex
                    LOGGER.warning("Sleeping for %ss time", delay)
                    time.sleep(delay)

            if last_exception is not None:
                raise type(last_exception)

            return result
        return wrapper
    return decorator


def bool_retry(retry_count=5, delay=2, expected_value=True):
    """
    Function to be used as decorator for retry mechanism for functions
    which return boolean value.

    :param retry_count: number of retry the function is executed
    :param delay: the seconds it wait after each execution
    :param expected_value: value which is expected from the function. Default: True
    :return:

    >>> @bool_retry(3, 2, False)
        def func(a, b):
            return a/b
    >>> func(5,3)
    """
    def decorator(function):
        @functools.wraps(function)
        def wrapper(*args, **kwargs):
            last_exception = None
            for _ in range(retry_count):
                try:
                    LOGGER.info("Trying for %s time.", _)
                    result = function(*args, **kwargs)
                    if not isinstance(result, bool):
                        raise ReturnTypeNotBooleanException(result)
                    if result == expected_value:
                        return result
                    raise ResultFalseException if expected_value is True else ResultTrueException
                except (ResultFalseException, ResultTrueException) as bool_ex:
                    last_exception = bool_ex
                    LOGGER.warning("Sleeping for %ss time", delay)
                    time.sleep(delay)

            if last_exception is not None:
                raise type(last_exception)

            return result
        return wrapper
    return decorator


def read_param_store(param_name, secure=False, region_name=None):
    """
    Read the parameter value from parameter store.

    :param param_name: Name (key) of the parameter
    :param secure: True if stored as SecuredString else False. Default: False
    :param region_name: Region of aws account

    :return:
    """
    try:
        client = boto3.client('ssm', region_name=region_name)
        value = client.get_parameter(
            Name=param_name,
            WithDecryption=secure
        )['Parameter']['Value']

        _response = format_response(0, 'Successfully retrieved param store value', value)
    except ClientError as cli_err:
        err_msg = 'Exception raised in function read_param_store : ' + str(cli_err)
        _response = format_response(1, err_msg, None)

    return _response


class WriteUtil:
    """
    Contain common functions for writing data
    """

    def __init__(self, bucket_name, region=None):
        """
        Initialize the Write object

        :param bucket_name: bucket name


        >>> writer = Write("lz_bucket")
        """

        self.region = region
        self.bucket_name = bucket_name

    @staticmethod
    def _get_prefix_local(
            domain_name,
            dataset_name,
            user,
            file_type,
            upload_date=None):
        """
        Returns the prefix for data to read

        :param domain_name: domain name for dataset
        :param dataset_name: dataset name
        :param user: UserId who has permission to upload data
        :param file_type: Type of data in the dataset. For ex., csv, pdf, png
        :param upload_date: date to use to upload the data
        :return:
        """

        if upload_date:
            _upload_date = str(int(upload_date))
        else:
            _upload_date = str(int(time.time()))

        _prefix = "/".join([domain_name,
                            dataset_name,
                            "upload_date=" + _upload_date,
                            user,
                            file_type,
                            "{0}_{1}".format(user,
                                             _upload_date)])

        return _prefix

    def send_success_file(
            self,
            domain_name,
            dataset_name,
            user,
            file_type):
        """
        Uploads the empty file with name _SUCCESS

        :param domain_name: domain name for dataset
        :param dataset_name: dataset name
        :param user: UserId who has permission to upload data
        :param file_type: Type of data in the dataset. For ex., csv, pdf, png
        :return:
        """

        empty_bytes = b""
        _prefix = "/".join(WriteUtil._get_prefix_local(domain_name, dataset_name, user,
                                                       file_type).split('/')[:-1]) + "/_SUCCESS"
        awshelper.put_object(self.bucket_name, _prefix, empty_bytes)
