"""
Data Landing Zone Util provides functions to get the status of Amorphic DataLake
"""

from amorphicutils import awshelper
from amorphicutils.datalandingzonestate import DataLandingZoneState


class DataLandingZoneUtil(DataLandingZoneState):
    """
    Util class to get state of DLZ
    """

    def __init__(self, lz_bucket_name, dlz_bucket_name, region=None):
        """
        Initialize DLZ Util

        :param lz_bucket_name: Lz bucket name
        :param dlz_bucket_name: Dlz bucket name
        """

        self.dlz_bucket_name = dlz_bucket_name
        self.region = region
        DataLandingZoneState.__init__(self, lz_bucket_name, dlz_bucket_name)

    def get_last_upload_date_folder_epoch(
            self, domain_name, dataset_name):
        """
        Get the epoch of folder when there was last upload

        :param domain_name: domain name of dataset
        :param dataset_name: dataset name
        :return:
        """

        last_epoch = max(self.get_epochs_list(domain_name, dataset_name))
        return last_epoch

    def get_epochs_list(self, domain_name, dataset_name):
        """
        Returns the list of epochs

        :param domain_name: domain name of dataset
        :param dataset_name: dataset name
        :return:
        """

        _prefix = "/".join([domain_name, dataset_name, ""])
        objs = awshelper.list_bucket_objects(
            self.dlz_bucket_name, _prefix, self.region)
        epochs = set()
        if objs:
            for obj in objs:
                epoch = obj['Key'].split("/")[2].split("=")[-1]
                epochs.add(epoch)
        epochs_list = sorted(epochs)
        return epochs_list

    def get_new_epochs(
            self,
            domain_name,
            dataset_name,
            last_processed_epoch=None):
        """
        Returns the list of epochs which are greater than last_processed_epoch

        :param domain_name: domain name of dataset
        :param dataset_name: dataset name
        :param last_processed_epoch: last epoch processed
        :return: list of new epochs
        """

        epochs_list = self.get_epochs_list(domain_name, dataset_name)
        if last_processed_epoch:
            return [epoch for epoch in epochs_list if epoch >
                    last_processed_epoch]
        return epochs_list

    def get_new_files_prefix(
            self,
            domain_name,
            dataset_name,
            last_processed_epoch=None):
        """
        Returns the list of file location whose epoch is greater than last_processed_epoch.

        :param domain_name: domain name of dataset
        :param dataset_name: dataset name
        :param last_processed_epoch: last epoch processed
        :return: list of new file location
        """

        _prefix = "/".join([domain_name, dataset_name, ""])
        objs = awshelper.list_bucket_objects(
            self.dlz_bucket_name, _prefix, self.region)
        if objs:
            files_prefixes = []
            for obj in objs:
                _epoch = obj['Key'].split("/")[2].split("=")[-1]
                if not last_processed_epoch:
                    files_prefixes.append(obj['Key'])
                elif int(_epoch) > int(last_processed_epoch):
                    files_prefixes.append(obj['Key'])
            return files_prefixes
        return None
