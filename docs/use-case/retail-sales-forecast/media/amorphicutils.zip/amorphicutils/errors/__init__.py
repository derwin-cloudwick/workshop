
"""
Exceptions
"""


class UnableToSaveException(ValueError):
    """ Exception raised because unable to save dataframe to s3 """


class DataNotInBytesException(ValueError):
    """ Exception raised due to data not being in byte format """


class UnableToReadException(ValueError):
    """ Raised exception because unable to read from s3 """


class ResultFalseException(ValueError):
    """ raise when result from function is False """


class ResultTrueException(ValueError):
    """ raise when result from function is True """


class ReturnTypeNotBooleanException(ValueError):
    """ raise exception when return type is of not boolean type """


class SchemaDetailsValidationException(ValueError):
    """ raise exception when schema details validation fails """


class SchemaValidationFailedWith(ValueError):
    """ raise exception when the schema validation fails """


class AmorphicTokenExpired(ValueError):
    """ raise Exception when amorphic token is expired """
