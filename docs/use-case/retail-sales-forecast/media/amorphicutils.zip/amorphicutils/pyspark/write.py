"""
Write using pyspark
=================
Defines class Write, which is used to write data to amorphic datalake backed by s3.
"""

import time
import boto3
from amorphicutils.common import WriteUtil, bool_retry
from amorphicutils.datalakeutil import DataLandingZoneUtil
from amorphicutils.amorphiclogging import Log4j


class Write(WriteUtil, DataLandingZoneUtil):
    """
    Class to write data from Amorphic
    """
    def __init__(self, bucket_name, spark, region=None):
        """
        Initialize the Write object

        :param bucket_name: Bucket name
        :param spark: SparkContext

        >>> writer = Write("lz_bucket", spark_object)
        """

        if region:
            self.s3_resource = boto3.resource("s3", region)
        else:
            self.s3_resource = boto3.resource("s3")
        self.region = region
        self.bucket = self.s3_resource.Bucket(bucket_name)
        self.bucket_name = bucket_name
        self._logger = Log4j(spark).get_logger()
        WriteUtil.__init__(self, bucket_name, region)
        dlz_bucket = "-".join(bucket_name.split("-")[0:-1] + ["dlz"])
        DataLandingZoneUtil.__init__(self,
                                     lz_bucket_name=bucket_name,
                                     dlz_bucket_name=dlz_bucket,
                                     region=region)

    def _get_prefix(
            self,
            domain_name,
            dataset_name,
            user,
            file_type,
            upload_date=None):
        """
        returns the prefix for data to read
        :param domain_name: domain name for dataset
        :param dataset_name: dataset name
        :param user: UserId who has permission to upload data
        :param file_type: Type of data in the dataset. For ex., csv, pdf, png
        :param upload_date: date to use to upload the data
        :return:
        """

        full_s3_path = "/".join(["s3:/", self.bucket_name,
                                 domain_name, dataset_name, ""])

        if upload_date:
            _upload_date = str(int(upload_date))
        else:
            _upload_date = str(int(time.time()))

        _prefix = full_s3_path + "upload_date=" + \
            _upload_date + "/" + user + "/" + file_type + "/"

        return _upload_date, _prefix

    # pylint: disable=too-many-arguments, too-many-locals
    def write_csv_data(
            self,
            data,
            domain_name,
            dataset_name,
            user,
            header=False,
            file_type="csv",
            quote=True,
            delimiter=",",
            upload_date=None,
            full_reload=False,
            path=None,
            **kwargs):
        """
        Write data to lz bucket

        :param data: spark dataframe of data
        :param domain_name: domain name for dataset
        :param dataset_name: dataset name
        :param user: username with write access to dataset
        :param header: True if you want to save file with header. Default: False
        :param file_type: file type for dataset
        :param quote: True if you want to save you data with quoted character. Default: True
        :param delimiter: The delimiter to use while storing file, Default: ,
        :param upload_date: Current timestamp from time.time(). If not supplied, then cuurent timestamp is used
        :param full_reload: True if the table type is of reload type, Default: False
        :param path: (Optional)Path where data is stored. Implicit creation of path will be ignored
        :param kwargs: Optional arguments avaiable for pyspark write

        :return: dict with exitcode and message

        >>> writer = Write("lz_bucket")
        >>> response = writer.write_csv_data(spark_df, "testdomain", "testdataset", user="userid", file_type="csv")
        >>> print(response)
        >>> {
          "exitcode": 0,
          "message": "This is success message"
          }
        """

        try:
            self._logger.info("In Write.write_csv_data, Writing csv data to dataset {0}.{1}".format(domain_name,
                                                                                                    dataset_name))
            if path:
                _prefix = path
            else:
                upload_date, _prefix = self._get_prefix(
                    domain_name, dataset_name, user, file_type, upload_date)

            if quote:
                data.write.csv(
                    _prefix,
                    quote="\"",
                    quoteAll=True,
                    header=header,
                    sep=delimiter,
                    **kwargs)
            else:
                data.write.csv(_prefix, header=header, sep=delimiter, **kwargs)

            if full_reload:
                result = bool_retry(5, 5, True)(self.is_epoch_dir_exists)(bucket_name=self.bucket_name,
                                                                          domain_name=domain_name,
                                                                          dataset_name=dataset_name,
                                                                          upload_date=upload_date,
                                                                          path=path,
                                                                          region=self.region)
                if result:
                    self.send_success_file(domain_name, dataset_name, user, file_type)
                    #super(Write, self).send_success_file(domain_name, dataset_name, user, file_type)
                else:
                    raise Exception("Failed to upload _SUCCESS file to trigger reload. Please trigger from UI.")

            response = {
                "exitcode": 0,
                "message": "Successfully saved data to s3."
            }
        except Exception as ex:
            response = {
                "exitcode": 1,
                "message": ex
            }
        return response

    def __write_avro_data(
            self,
            data,
            domain_name,
            dataset_name,
            user,
            file_type="csv",
            quote=True,
            upload_date=None,
            path=None):
        """
        Write data to lz bucket in avro format

        :param data: spark dataframe of data
        :param domain_name: domain name for dataset
        :param dataset_name: dataset name
        :param user: username with write access to dataset
        :param file_type: file type for dataset
        :param quote: True if you want to save you data with quoted character. Default: True
        :param upload_date: Current timestamp from time.time(). If not supplied, then cuurent timestamp is used
        :param path: (Optional)Path where data is stored. Implicit creation of path will be ignored
        :return:
        """

        try:

            if path:
                _prefix = path
            else:
                upload_date, _prefix = self._get_prefix(
                    domain_name, dataset_name, user, file_type, upload_date)

            if quote:
                data.write.format("avro").save(_prefix)
            else:
                data.write.format("avro").save(_prefix)
            response = {
                "exitcode": 0,
                "message": "Successfully saved data to s3 in avro format."
            }
        except Exception as ex:
            response = {
                "exitcode": 1,
                "message": ex
            }
        return response
